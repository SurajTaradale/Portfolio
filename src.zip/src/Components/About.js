import '../Style/About.css';
import aboutimg from '../Assets/img3.jpg';
import CV from '../Assets/CV.pdf'
import { Row, Col } from 'react-bootstrap';
function About() {

   return (
      <div className="About" id="about">
         <div class="Aboutcontainer">
            <p style={{ textAlign: 'center', fontSize: '24px', marginBottom: '0.5rem', fontWeight: '600', }}>About Me</p>
            <Row className="AboutRow">
               <Col sm={4}>
                  <div class="Aboutimg-area">
                     <div class="Aboutinner-area">
                        <img loading='lazy' src={aboutimg} alt="" />
                     </div>
                  </div>
               </Col>
               <Col sm={8} class="">
                  <div class="Aboutimg-area Aboutcol">
                     <div class="Aboutinner-area area">
                        <div className='Aboutme'>
                           <p>
                              Hi, I am Suraj Taradale
                              I am web developer and web designer
                              I pursued my <b>Graduation</b> at Visvesvaraya Technological University (VTU)
                              I completed <b>Full Stack Development Course</b> at Kodnest technology bengalore
                              I have certificate on <b>JavaScript Course</b> in freecodecamp.
                           </p>
                           <div>
                              <Row>
                                 <Col style={{ display: 'flex' }}>
                                    <a className='telno' href="tel:+918123632123"><div class="circle"><i class="fa fa-phone phicon"></i></div></a>
                                    <div style={{ fontWeight: '500' }}> <p>8123632123</p></div>
                                 </Col>
                                 <Col style={{ display: 'flex' }}>
                                    <a className='EmailIcon' href="mailto:surajtaradale@gmail.com"><i class="fa fa-envelope" aria-hidden="true" style={{ fontSize: '35px' }}></i></a>
                                    <div style={{ fontWeight: '500' }}><p>surajtaradale@gmail.com</p></div>
                                 </Col>
                              </Row>
                           </div>
                           <div class="Aboutbuttons">
                              <button className='viewbtn'><i class="fa fa-eye" aria-hidden="true" style={{marginRight:'2%'}}></i>View CV</button>
                              <a style={{ width: '30%' }} href={CV} download><button className='viewbtn' style={{ width: '100%' }}><i class="fa fa-download" aria-hidden="true" style={{marginRight:'2%'}}></i>Download CV</button></a>
                           </div>
                        </div>
                     </div>
                  </div>
               </Col>
            </Row>
         </div>

      </div>
   );
}

export default About;