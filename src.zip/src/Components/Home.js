import '../Style/Home.css';
import React from 'react';
import logo from '../Assets/img2.JPEG';
import 'bootstrap/dist/css/bootstrap.min.css';
import Typewriter from "typewriter-effect";
import { Link } from 'react-router-dom';
import { Row, Col } from 'react-bootstrap';
import CV from '../Assets/CV.pdf'
function Home() {
    return (
        <div id="home">
            <div className="Home " style={{ height: '100%' }}>
                <div>
                    <Row>
                        <Col sm={4}>
                            <div class="container1">
                                <div className=" Imgcontent">
                                    <div class="img-area">
                                        <div class="inner-area">
                                            <img src={logo} alt="" />
                                        </div>
                                    </div>
                                    <div class="social-icons">
                                        <a href="https://github.com/SurajTaradale" class="fb" target='blanck'><i class="fab fa-github"></i></a>
                                        <a href="https://www.linkedin.com/in/suraj-taradale-ab124b197/" target='blanck' class="twitter"><i class="fab fa-linkedin-in"></i></a>
                                        <a href="mailto:surajtaradale@gmail.com" class="twitter" target='blanck'> <i class="fas fa-envelope-square"></i></a>
                                        <a href="https://www.instagram.com/s_u_r_a_j.8002/" class="insta" target='blanck'><i class="fab fa-instagram"></i></a>
                                    </div>
                                </div>

                            </div>
                        </Col>
                        <Col sm={8}>
                            <div className="headName" id="title">
                                <p className='Name'>Hi, I am Suraj</p>
                                <Typewriter
                                    onInit={(typewriter) => {
                                        typewriter
                                            .typeString("Web Developer")
                                            .pauseFor(1000)
                                            .deleteAll()
                                            .typeString("Web Designer")
                                            .start();
                                    }}
                                />
                                <div class="buttons">
                                    <Row>
                                        <Col >
                                            <Link to="/View"><button><i class="fa fa-eye" aria-hidden="true" style={{marginRight:'2%'}}></i>View Cv</button></Link>
                                        </Col>
                                        <Col>
                                            <a href={CV} download><button><i class="fa fa-download" aria-hidden="true" style={{marginRight:'2%'}}></i>Download CV</button></a>
                                        </Col>
                                    </Row>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </div>
            </div>
        </div>
    );
}

export default Home;
