import React from 'react';
import { pdfjs, Document, Page } from "react-pdf";
import CV from '../Assets/CV.pdf'
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
const View = () => {

  return (
    <div>
      <Document file={CV}>
        <Page pageNumber={1} />
      </Document>

    </div>
  )
}

export default View