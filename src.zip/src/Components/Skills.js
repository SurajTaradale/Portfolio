import React, { useState } from 'react';
import '../Style/Skills.css';
import css from '../Assets/css.jpg';
import html from '../Assets/html.png';
import js from '../Assets/js.png';
import perl from '../Assets/perl.png';
import sql from '../Assets/sql.png';
import reactjs from '../Assets/reactjs.png';
import { Row, Col } from 'react-bootstrap';
import "react-step-progress-bar/styles.css";
function Skills() {
    const [HTML, setHTML] = useState("skillsinfo1");
    const [CSS, setCSS] = useState("skillsinfo");
    const [JS, setJS] = useState("skillsinfo");
    const [SQL, setSQL] = useState("skillsinfo");
    const [Perl, setPerl] = useState("skillsinfo");
    const [ReactJS, setReactJS] = useState("skillsinfo");

    const HTMLcard = (e) => {

        setCSS('skillsinfo');
        setJS('skillsinfo');
        setSQL('skillsinfo');
        setPerl('skillsinfo');
        setReactJS('skillsinfo');

        setHTML('skillsinfo1');


    }
    const CSScard = (e) => {
        setHTML('skillsinfo');
        setJS('skillsinfo');
        setSQL('skillsinfo');
        setPerl('skillsinfo');
        setReactJS('skillsinfo');

        setCSS('skillsinfo1');

    }
    const JScard = (e) => {
        setHTML('skillsinfo');
        setCSS('skillsinfo');
        setSQL('skillsinfo');
        setPerl('skillsinfo');
        setReactJS('skillsinfo');

        setJS('skillsinfo1');

    }
    const Sqlcard = (e) => {
        setHTML('skillsinfo');
        setCSS('skillsinfo');
        setJS('skillsinfo');
        setPerl('skillsinfo');
        setReactJS('skillsinfo');

        setSQL('skillsinfo1');

    }
    const Perlcard = (e) => {
        setHTML('skillsinfo');
        setCSS('skillsinfo');
        setJS('skillsinfo');
        setSQL('skillsinfo');
        setReactJS('skillsinfo');

        setPerl('skillsinfo1');

    }
    const Reactjscard = (e) => {
        setHTML('skillsinfo');
        setCSS('skillsinfo');
        setJS('skillsinfo');
        setSQL('skillsinfo');
        setPerl('skillsinfo');

        setReactJS('skillsinfo1');

    }
    return (
        <div className=' skills' id='skills'>
            <div className="SkillsTitle"> <p>Skills</p></div>
            <div className="container">
                <Row>
                    <Col sm={4}>

                        <div className='SkillsList'>
                            <div className='card SkillsCard' onMouseOver={HTMLcard}>

                                <div class="card_image"> <img src={html} alt='HTML' /> </div>

                                {/* <div class="card_title title-white">
                            <p>Card Title</p>
                        </div> */}

                            </div>
                            <div className='card SkillsCard' onMouseOver={CSScard}>
                                <div class="card_image"> <img src={css} style={{ background: 'black', }} alt='CSS' /> </div>
                            </div>
                            <div className='card SkillsCard' onMouseOver={JScard}>
                                <div class="card_image"> <img src={js} style={{ background: 'black', }} alt='JS' /> </div>
                            </div>
                            <div className='card SkillsCard' onMouseOver={Sqlcard}>
                                <div class="card_image"> <img src={sql} alt='SQL' /> </div>
                            </div>
                            <div className='card SkillsCard' onMouseOver={Perlcard}>
                                <div class="card_image"> <img src={perl} alt='PERL' /> </div>
                            </div>
                            <div className='card SkillsCard' onMouseOver={Reactjscard}>
                                <div class="card_image"> <img src={reactjs} alt='REACT' /> </div>
                            </div>

                        </div>
                    </Col>
                    <Col sm={8}>
                        <div className={HTML}>
                            <Row className='skillscard2'>
                                <Col sm={8}>
                                    <div className='SkillName'>
                                        <p className="Title" style={{ color: 'rgb(227, 76, 38)' }}>HTML</p>
                                        <div class="htmlProg ProgWidth">
                                            <div class="p">
                                                <p className='per'>Html</p>
                                                <p className='per'>95%</p>
                                            </div>
                                            <div class="pp">
                                                <div class="skillDiv">
                                                    <span class="skillBar htmlBar" style={{ background: 'rgb(227, 76, 38)' }}></span>
                                                </div>
                                            </div>
                                            <div style={{ display: 'flex', marginTop: '10%' }}><b>Experience:{' '} </b><p> HTML5 (most recent)</p></div>
                                        </div>

                                    </div>
                                </Col>
                                <Col sm={4}>
                                    <div className='SkillImg'>
                                        <img loading='lazy' src={html} className='card_image1' width='100%' height='100%' alt='HTML'></img>
                                    </div>
                                </Col>
                            </Row>
                        </div>


                        <div className={CSS}>
                            <Row className='skillscard2'>
                                <Col sm={8}>
                                    <div className='SkillName'>
                                        <p className="Title" style={{ color: 'rgb(0, 131, 222)' }}>CSS</p>
                                        <div class="cssProg ProgWidth">
                                            <div class="p">
                                                <p className='per'>Css</p>
                                                <p className='per'>80%</p>
                                            </div>
                                            <div class="pp">
                                                <div class="skillDiv">
                                                    <span class="skillBar cssBar" style={{ background: 'rgb(0, 131, 222)' }}></span>
                                                </div>
                                            </div>
                                            <div style={{ display: 'flex', marginTop: '10%' }}><b>Experience: </b><p> CSS3 (most recent)</p></div>
                                        </div>

                                    </div>
                                </Col>
                                <Col sm={4}>
                                    <div className='SkillImg'>
                                        <img loading='lazy' src={css} className='card_image1' width='100%' height='100%' alt='CSS'></img>
                                    </div>
                                </Col>
                            </Row>
                        </div>
                        <div className={JS}>
                            <Row className='skillscard2'>
                                <Col sm={8}>
                                    <div className='SkillName'>
                                        <p className="Title" style={{ color: '#f7bd1beb' }}>JavaScript</p>
                                        <div class="jsProg ProgWidth">
                                            <div class="p">
                                                <p className='per'>JavaScript</p>
                                                <p className='per'>75%</p>
                                            </div>
                                            <div class="pp">
                                                <div class="skillDiv">
                                                    <span class="skillBar jsBar" style={{ background: '#f7bd1beb' }}></span>
                                                </div>
                                            </div>
                                            <div style={{ display: 'flex', marginTop: '10%' }}><b>Experience: </b><p> ES6, DOM (most recent)</p></div>
                                        </div>

                                    </div>
                                </Col>
                                <Col sm={4}>
                                    <div className='SkillImg'>
                                        <img loading='lazy' src={js} className='card_image1' width='100%' height='100%' alt='JS'></img>
                                    </div>
                                </Col>
                            </Row>
                        </div>
                        <div className={SQL}>
                            <Row className='skillscard2'>
                                <Col sm={8}>
                                    <div className='SkillName'>
                                        <p className="Title" style={{ color: '#007bff' }}>DataBase</p>
                                        <div class="sqlProg ProgWidth">
                                            <div class="p">
                                                <p className='per'>Sql</p>
                                                <p className='per'>65%</p>
                                            </div>
                                            <div class="pp">
                                                <div class="skillDiv">
                                                    <span class="skillBar sqlBar" style={{ background: '#007bff' }}></span>
                                                </div>
                                            </div>
                                            <div style={{ display: 'flex', marginTop: '10%' }}><b>Experience: </b><p> Perl</p></div>
                                        </div>
                                    </div>
                                </Col>
                                <Col sm={4}>
                                    <div className='SkillImg'>
                                        <img loading='lazy' src={sql} className='card_image1' width='100%' height='100%' alt='SQL'></img>
                                    </div>
                                </Col>
                            </Row>
                        </div>
                        <div className={Perl}>
                            <Row className='skillscard2'>
                                <Col sm={8}>
                                    <div className='SkillName'>
                                        <p className="Title" style={{ color: 'rgb(0, 131, 222)' }}>Perl</p>
                                        <div class="Perl ProgWidth">
                                            <div class="p">
                                                <p className='per'>Perl</p>
                                                <p className='per'>70%</p>
                                            </div>
                                            <div class="pp">
                                                <div class="skillDiv">
                                                    <span class="skillBar PerlBar" style={{ background: 'rgb(0, 131, 222)' }}></span>
                                                </div>
                                            </div>
                                            <div style={{ display: 'flex', marginTop: '10%' }}><b>Experience: </b><p> Perl (most recent)</p></div>
                                        </div>
                                    </div>
                                </Col>
                                <Col sm={4}>
                                    <div className='SkillImg'>
                                        <img loading='lazy' src={perl} className='card_image1' width='100%' height='100%' alt='PERL'></img>
                                    </div>
                                </Col>
                            </Row>
                        </div>
                        <div className={ReactJS}>
                            <Row className='skillscard2'>
                                <Col sm={8}>
                                    <div className='SkillName'>
                                        <p className="Title" style={{ color: '#31d0f1' }}>React</p>
                                        <div class="reactProg ProgWidth">
                                            <div class="p">
                                                <p className='per'>React</p>
                                                <p className='per'>70%</p>
                                            </div>
                                            <div class="pp">
                                                <div class="skillDiv">
                                                    <span class="skillBar reactBar" style={{ background: '#31d0f1' }}></span>
                                                </div>
                                            </div>
                                            <div style={{ display: 'flex', marginTop: '10%' }}><b>Experience: </b><p> ReactJS,React Native, NextJS</p></div>
                                        </div>
                                    </div>
                                </Col>
                                <Col sm={4}>
                                    <div className='SkillImg'>
                                        <img loading='lazy' src={reactjs} className='card_image1' width='100%' height='100%' alt='REACT'></img>
                                    </div>
                                </Col>
                            </Row>
                        </div>
                    </Col>
                </Row>
            </div>
        </div>
    )
}

export default Skills;