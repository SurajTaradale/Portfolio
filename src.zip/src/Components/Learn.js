import '../Style/Learn.css';
import certificate1 from '../Assets/certificate1.PNG';
import certificate2 from '../Assets/certificate2.png';
import { Row, Col } from 'react-bootstrap';
function Learn() {

  return (
    <div className="Learn" id='Learn'>
      <div className="SkillsTitle"> <p>Certificates</p></div>
      <Row className='certificate'>
        <Col sm={4}>
          <div class="Aboutimg-area12">
            <div class="Aboutinner-area12">
              <img loading='lazy' src={certificate1} alt="" />
            </div>
          </div>
        </Col>
        <Col sm={4}>
          <div class="Aboutimg-area12">
            <div class="Aboutinner-area12">
              <img loading='lazy' src={certificate2} alt="" />
            </div>
          </div>
        </Col>
        <Col sm={4}>
          <div class="Aboutimg-area12">
            <div class="Aboutinner-area12">
              <img loading='lazy' src={certificate2} alt="" />
            </div>
          </div>
        </Col>
      </Row>

    </div>

  );
}

export default Learn;