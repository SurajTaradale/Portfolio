import '../Style/GlassHome.css';
import '../Style/Home.css';
import React from 'react';
import logo from '../Assets/img2.JPEG';
import 'bootstrap/dist/css/bootstrap.min.css';
import Typewriter from "typewriter-effect";
import { Row, Col } from 'react-bootstrap';
function GlassHome() {

    return (
        <div className="GlassHome">
            <header>
                <div className="logo"><a href="#">Logo</a></div>
                <div>
                    <Row>
                        <Col sm={4}>
                            <div class="container1">
                                <div className=" Imgcontent">
                                    <div class="img-area">
                                        <div class="inner-area">
                                            <img src={logo} alt="" />
                                        </div>
                                    </div>
                                    <div class="social-icons">
                                        <a href="#" class="fb"><i class="fab fa-github"></i></a>
                                        <a href="#" class="twitter"><i class="fab fa-linkedin-in"></i></a>
                                        <a href="#" class="twitter"> <i class="fas fa-envelope-square"></i></a>
                                        <a href="#" class="insta"><i class="fab fa-instagram"></i></a>
                                    </div>
                                </div>

                            </div>
                        </Col>
                        <Col sm={8}>
                            <div className="col-md-8 headName" id="title">
                                <p>Hi,I am Suraj</p>
                                <Typewriter
                                    onInit={(typewriter) => {
                                        typewriter
                                            .typeString("Web Deveplor")
                                            .pauseFor(1000)
                                            .deleteAll()
                                            .typeString("Web Designer")
                                            .start();
                                    }}
                                />

                                <div class="buttons">
                                    <Row>
                                        <Col>
                                            <button>View CV</button>
                                        </Col>
                                        <Col>
                                            <button>Download CV</button>
                                        </Col>
                                    </Row>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </div>
            </header>
        </div>
    );
}

export default GlassHome;